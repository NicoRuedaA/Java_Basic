//42313237e
//Nicolás Daniel Rueda Araque
//13/01/26

package es.cide.programacio;

public abstract interface graella {
    // interfaz graella

    public void posarCarnAGraella();
    // posam carn a la graella

    public void llevarCarnDeGraella();
    // llevam carn de la graella

    public boolean estaFet();
    // devolver un booleano segun el objeto
}
