//42313237e
//Nicolás Daniel Rueda Araque
//13/01/26

package es.cide.programacio;

public interface menjar {
    public void assaborir();
    // assaborim la carn

    public boolean crema();
    // devover true o flase en 50-50%

}
