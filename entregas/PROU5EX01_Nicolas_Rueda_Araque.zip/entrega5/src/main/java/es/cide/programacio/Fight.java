package es.cide.programacio;

public interface Fight {

    void insultar();

    void defensar();
}
