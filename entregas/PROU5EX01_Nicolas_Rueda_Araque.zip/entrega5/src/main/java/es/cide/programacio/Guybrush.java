package es.cide.programacio;

import java.util.Random;
import java.util.Scanner;

public class Guybrush extends Heroi {

    // vida (inicial) constante
    private static final int VIDA_INICIAL = 12;

    // ***CONSTRUCTORES***
    public Guybrush(Insult[] arrResp) {
        super("Guybrush", VIDA_INICIAL, arrResp);
        sayHello();
    }

    // ***METODOS PUBLICOS***
    @Override
    public void sayHello() {
        String saludo = UI.VERDE + " \"¡Ajá! ¡Sabía que tenías buen gusto! Soy Guybrush Threepwood, ¡Poderoso Pirata!\n"
                + //
                "\n" + //
                "Prepárate, porque esta vez voy en serio. Tengo un abrigo de cuero, tengo un mapa (creo) y, lo más importante... mira esto: *se señala la cara* ¡Tengo barba! Bueno, es una pelusilla muy masculina, pero cuenta.\n"
                + //
                "\n" + //
                "¡Vamos a encontrar el Big Whoop antes de que LeChuck vuelva a fastidiarlo todo!\"";
        UI.escribirLento(saludo, 7);
        UI.pausa(1000);
        System.out.println();
    }

    @Override
    public void sayGoodBye() {
        String despedida = UI.VERDE + "Bueno... ¿Sabes por qué los piratas no saben las letras del abecedario?\n" +
                "¡Porque se pierden en la C (sea)! ... ¿Lo pillas? 'Sea' es mar en inglés... vale, ya me voy."
                + UI.RESET;

        UI.escribirLento(despedida, 7);
    }

    @Override
    public void defensar() {

        UI.escribirLento(" ¿Qué le contestas? (1-5)", 15);
        System.out.println();
        // mostramos las respuestas

        // mezclamos las respuestas
        mezclar();

        // como la array está mezclada, imprimimos solo los 5 primeros, será random
        for (int i = 0; i < 5; i++) {
            UI.escribirLento((i + 1) + " " + arrayRespuestas[i].getTextoRespuesta(), 5);
            System.out.println();
        }

        /*
         * 
         * Random random = new Random();
         * int x = random.nextInt(2);
         * if (x == 1) {
         * // mostramos la primera mitad de las respuestas
         * for (int i = 0; i < arrayRespuestas.length / 2; i++) {
         * UI.escribirLento((i + 1) + " " + arrayRespuestas[i].getTextoRespuesta(), 5);
         * System.out.println();
         * }
         * }
         * 
         * else {
         * // mostramos la segunda mitade las respuestas
         * for (int i = arrayRespuestas.length / 2; i < arrayRespuestas.length; i++) {
         * UI.escribirLento((i + 1) + " " + arrayRespuestas[i].getTextoRespuesta(), 5);
         * System.out.println();
         * }
         * }
         */

    }

    // override porque guybrush solo tiene 5 respuestas
    @Override
    public String elegirRespuesta() {
        Scanner scHeroi = new Scanner(System.in); // no hace falta cerrarlo. Basta con cerrar Scanner al final en el
                                                  // main. Lo ideal sería pasar el scanner del main tal que defensar(sc)

        int respuesta = getInputValidado(scHeroi);
        // devolvemos la respuesta elegida
        return this.arrayRespuestas[respuesta].getTextoRespuesta();
    }

    // override porque guybrush solo tiene 5 respuestas
    @Override
    public int getInputValidado(Scanner scan) {
        // validamos el input de defensar()
        int res = -1;
        System.out.println();

        // mientras el input no esté contenido entre 1 y 10, repetimos
        while (res < 1 || res > 5) {
            System.out.println();
            UI.escribirLento(("Introdueix la teva resposta 1-5: "), 15);
            // miramos si se introduce un dato de tipo diferente a int
            try {
                res = scan.nextInt();
                if (res < 1 || res > 5)
                    // hemos introducido un valor fuera de rango
                    UI.escribirLento(("Fuera de rango:"), 15);
            } catch (Exception e) {
                // limpiamos buffer
                scan.next();
            }
            System.out.println();
        }

        // devolvemos la posición de la respuesta elegida. Restamos 1 ya que el usuario
        // elige a partir del 1, no el 0
        return res - 1;
    }

    public void mezclar() {
        Random random = new Random();
        // Fisher-Yates para mezclar la array
        for (int i = arrayRespuestas.length - 1; i > 0; i--) {
            int j = random.nextInt(i + 1);

            Insult aux = arrayRespuestas[i];
            arrayRespuestas[i] = arrayRespuestas[j];
            arrayRespuestas[j] = aux;
        }
    }

}
