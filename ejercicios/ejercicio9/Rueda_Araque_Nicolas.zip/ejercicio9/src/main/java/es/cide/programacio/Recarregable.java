package es.cide.programacio;

interface Recarregable {
    void carregarBateria();

    int getNivellBateria();
}
